from google_drive_downloader import GoogleDriveDownloader as gdd

gdd.download_file_from_google_drive(file_id='1lgpHENZm2HGhEVHAIX4mK_ATSU_ujeqy',
                                    dest_path='./ckpt_e401dd2_ep00400_loss3.2541_lr0.00095.pth.tar',
                                    unzip=False)
